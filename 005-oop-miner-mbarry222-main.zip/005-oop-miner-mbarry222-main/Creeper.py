import random
import pygame

from Mob import Mob


class Creeper(Mob):
    def __init__(self, window, WINDOW_WIDTH, WINDOW_HEIGHT):
        super().__init__(window, WINDOW_WIDTH, WINDOW_HEIGHT)
        self.window = window
        self.WINDOW_WIDTH = WINDOW_WIDTH
        self.WINDOW_HEIGHT = WINDOW_HEIGHT
        self.image = pygame.image.load('creeper.png')
        self.image = pygame.transform.scale(self.image, (50, 50))
        self.speed = random.choice([3, 4])
        self.direction = pygame.math.Vector2(random.choice([-1, 1]), random.choice([-1, 1]))
        self.position = pygame.Rect(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2, 50, 50)
        self.speed = [1, 2]

        pos = 100
        pos_x, pos_y = WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2
        while True:
            self.position.y = random.randint(0, self.WINDOW_WIDTH - self.position.height)
            self.position.x = random.randint(0, self.WINDOW_WIDTH - self.position.width)
            if (abs(self.position.x - pos_x) > pos) and (abs(self.position.y - pos_y) > pos):
                break

    def update(self):
        self.position.x += self.speed[0]
        self.position.y += self.speed[1]
        if self.position.right >= self.WINDOW_WIDTH or self.position.left <= 0:
            self.speed[0] = -self.speed[0]
        if self.position.bottom >= self.WINDOW_HEIGHT or self.position.top <= 0:
            self.speed[1] = -self.speed[1]

    def draw(self):
        self.window.blit(self.image, self.position)

    def get_rect(self):
        return self.position
