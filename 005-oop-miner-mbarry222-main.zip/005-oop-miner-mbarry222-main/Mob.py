import pygame
import random


class Mob:
    def __init__(self, window, WINDOW_WIDTH, WINDOW_HEIGHT):
        self.window = window
        self.WINDOW_WIDTH = WINDOW_WIDTH
        self.WINDOW_HEIGHT = WINDOW_HEIGHT
        self.speed = 0
        self.image = ''
        self.position = random.randint(0, WINDOW_WIDTH - self.WINDOW_WIDTH)
        self.position = random.randint(0, WINDOW_HEIGHT - self.WINDOW_HEIGHT)

    def update(self):
        return self.position

    def draw(self):
       return self.image

    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.WINDOW_WIDTH, self.WINDOW_HEIGHT)
