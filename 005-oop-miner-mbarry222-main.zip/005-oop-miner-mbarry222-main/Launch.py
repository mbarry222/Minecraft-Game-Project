import pygame
from Player import Player
from Creeper import Creeper
from Chicken import Chicken
from Zombie import Zombie
from Cow import Cow

pygame.init()

WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
FRAMES_PER_SECOND = 30


screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption('Miners Game')


player_image = pygame.image.load('player.jpg').convert_alpha()
chicken_image = pygame.image.load('chicken.png')
cow_image = pygame.image.load('cow.jpg')
creeper_image = pygame.image.load('creeper.png')
zombie_image = pygame.image.load('zombie.jpg')

player = Player(screen, WINDOW_WIDTH, WINDOW_HEIGHT)
npcs = [Creeper(screen, WINDOW_WIDTH, WINDOW_HEIGHT) for _ in range(3)] + \
       [Chicken(screen, WINDOW_WIDTH, WINDOW_HEIGHT) for _ in range(5)] + \
       [Zombie(screen, WINDOW_WIDTH, WINDOW_HEIGHT) for _ in range(2)] + \
       [Cow(screen, WINDOW_WIDTH, WINDOW_HEIGHT) for _ in range(3)]


clock = pygame.time.Clock()
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False


    screen.fill((0, 0, 0))
    player.update()
    player.draw()

    for npc in npcs:
        npc.update()

    for npc in npcs:
        npc.draw()


    for npc in npcs[:]:
        if player.check_collide(npc.get_rect()):
            if isinstance(npc, Creeper):
                print(f"Game Over! Your score: {player.score}")
                running = False
            elif isinstance(npc, Zombie):
                player.score += 25
                npcs.remove(npc)
                if not any(isinstance(npc, Zombie) for npc in npcs):
                    print(f"Game Over! You cleared all the zombies. Your score: {player.score}")
                    running = False
            elif isinstance(npc, Cow):
                player.score -= 10
                npcs.remove(npc)
            elif isinstance(npc, Chicken):
                player.score -= 5
                npcs.remove(npc)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
