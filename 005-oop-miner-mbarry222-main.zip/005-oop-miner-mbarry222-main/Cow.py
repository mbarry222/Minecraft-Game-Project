from Mob import Mob
import random
import pygame

class Cow(Mob):
    def __init__(self, window, WINDOW_WIDTH, WINDOW_HEIGHT):
        super().__init__(window, WINDOW_WIDTH, WINDOW_HEIGHT)
        self.window = window
        self.windowWidth = WINDOW_WIDTH
        self.windowHeight = WINDOW_HEIGHT
        self.image = pygame.image.load('cow.jpg')
        self.image = pygame.transform.scale(self.image, (50, 50))
        self.position = self.image.get_rect()


        self.position.x = random.randint(0, self.windowWidth - self.position.width)
        self.position.y = random.randint(0, self.windowHeight - self.position.height)


        self.speed = [0, 2]

    def update(self):
        # Update vertical position based on speed
        self.position.y += self.speed[1]

        if self.position.bottom >= self.windowHeight or self.position.top <= 0:
            self.speed[1] = -self.speed[1]

    def draw(self):
        self.window.blit(self.image, self.position)

    def get_rect(self):
        return self.position