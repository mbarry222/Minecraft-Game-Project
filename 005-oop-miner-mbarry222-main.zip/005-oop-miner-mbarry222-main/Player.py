import pygame


class Player:
    def __init__(self, window, WINDOW_WIDTH, WINDOW_HEIGHT):
        self.window = window
        self.WINDOW_WIDTH = 50
        self.WINDOW_HEIGHT = 50
        self.image = pygame.image.load('player.jpg')
        self.image = pygame.transform.scale(self.image, (50, 50))  # Scale as needed
        self.position = pygame.Rect(WINDOW_WIDTH // 2 - 25, WINDOW_HEIGHT // 2 - 25, 50, 50)
        self.score = 0

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.position.x -= 5
        if keys[pygame.K_RIGHT]:
            self.position.x += 5
        if keys[pygame.K_UP]:
            self.position.y -= 5
        if keys[pygame.K_DOWN]:
            self.position.y += 5

    def check_collide(self, other_character):
        # Check if other_character is directly a pygame.Rect or needs to call get_rect()
        if isinstance(other_character, pygame.Rect):
            return self.position.colliderect(other_character)
        else:
            return self.position.colliderect(other_character.get_rect())

    def draw(self):
        self.window.blit(self.image, self.position.topleft)


    def score(self, value):
        if isinstance(value, int):
            self.score = value

    def get_rect(self):
        return self.position
