from Mob import Mob
import random
import pygame

class Chicken(Mob):
    def __init__(self, window, WINDOW_WIDTH, WINDOW_HEIGHT):
        super().__init__(window, WINDOW_WIDTH, WINDOW_HEIGHT)
        self.window = window
        self.windowWidth = WINDOW_WIDTH
        self.windowHeight = WINDOW_HEIGHT
        self.image = pygame.image.load('chicken.png')
        self.image = pygame.transform.scale(self.image, (50, 50))
        self.position = self.image.get_rect()


        self.position.x = random.randint(0, self.windowWidth - self.image.get_width())
        self.position.y = random.randint(0, self.windowHeight - self.image.get_height())


        self.speed = [2, 0]

    def update(self):

        self.position.x += self.speed[0]

        # Reverses direction at window boundaries
        if self.position.right >= self.windowWidth or self.position.left <= 0:
            self.speed[0] = -self.speed[0]

    def draw(self):
        self.window.blit(self.image, self.position)

    def get_rect(self):
        return self.position